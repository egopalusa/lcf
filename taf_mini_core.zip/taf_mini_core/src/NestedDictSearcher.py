class NestedDictSearcher:
    def __init__(self, target_dict) -> None:
        if not isinstance(target_dict, dict):
            raise ValueError("The Provided target must be a dictionary")
        self.target_dict = target_dict

    def find_key_value(self, search_param):
        if isinstance(search_param, dict):
            return self._check_dict(search_param)
        return self._check_key_or_value(search_param)

    def _check_dict(self, search_param):
        for key, value in search_param.items():
            if key not in self.target_dict:
                return False
            if isinstance(value, dict):
                nested_searcher = NestedDictSearcher(self.target_dict[key])
                if not nested_searcher.find_key_value(value):
                    return False
            elif self.target_dict[key] != value:
                return False
        return True

    def _check_key_or_value(self, search_param):
        for key, value in self.target_dict.items():
            if key == search_param or value == search_param:
                return True
            if isinstance(value, (dict, list)):
                if isinstance(value, dict):
                    nested_searcher = NestedDictSearcher(value)
                    if nested_searcher.find_key_value(search_param):
                        return True
                elif any(
                    isinstance(item, dict)
                    and NestedDictSearcher(item).find_key_value(search_param)
                    for item in value
                ):
                    return True
        return False


nested_dict = {
    "user": {
        "name": "test",
        "age": 30,
        "address": {"city": "test_city", "postal_code": 95742},
    },
    "items": [
        {"id": 1, "value": "apple"},
        {"id": 2, "value": "banana"},
    ],
}

searcher = NestedDictSearcher(nested_dict)
print(searcher.find_key_value("name"))
print(searcher.find_key_value(30))
print(searcher.find_key_value("city"))
print(searcher.find_key_value("address"))
print(searcher.find_key_value("banana"))
print(searcher.find_key_value("banana"))

search_dict = {
    "user": {
        "name": "test",
        "age": 30,
        "address": {"city": "test_city", "postal_code": 95741},
    }
}
print(searcher.find_key_value(search_dict))