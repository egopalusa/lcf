class GlobalConfig:

    def __init__(self, api_name, env_name, test_type, config_file_path) -> None:
        self.api_name = api_name
        self.env_name = env_name
        self.test_type = test_type
        self.config_file_path = config_file_path
