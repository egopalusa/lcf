from pathlib import Path


base_path = Path.cwd()
default_path = base_path.joinpath("taf_mini_core", "config", "settings.yaml")
config_path = base_path.joinpath("tests", "config")
td_path = base_path.parent.joinpath("taf_mini_core", "tests", "docs")
PREDEFINED_COLS = ['id','tc_name','path_to_json_template','count','db_sources','path_to_in_query','path_to_out_query','path_to_json_template']